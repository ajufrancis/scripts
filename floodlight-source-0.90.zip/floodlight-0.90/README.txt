  
  Floodlight
  An Apache licensed, Java based OpenFlow controller

Floodlight is a Java based OpenFlow controller originally written by David Erickson at Stanford
University. It is available under the Apache 2.0 license.

For documentation, forums, issue tracking and more visit:

      http://www.openflowhub.org/display/Floodlight/Floodlight+Home
