package net.floodlightcontroller.core.module;

public class FloodlightModuleException extends Exception {
	private static final long serialVersionUID = 1L;

	public FloodlightModuleException(String error) {
		super(error);
	}
}
