
send_http_header(1, 'Known ntop hosts')
sendString('Hello')
send_html_footer()