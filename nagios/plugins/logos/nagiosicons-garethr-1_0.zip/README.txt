Nagios icons for AIX, Linux on Power, iSeries, and others
---------------------------------------------------------

Version:       1.0
Release date:  2009-05-02


Contains icons at 40x40 size for:

AIX 4, 5 and 6
AIX 5 and 6 with Oracle
IBM i (iSeries)
Linux on Power
Power architecture
Redhat Linux


Description and copyright:

These images are simply reduced-size copies of copyrighted images. Some include multiple originals in a single image. The copyrights remain with their respective owners, who include IBM, Oracle, Power.org, and Redhat.

These images are provided here as a convenience. It is assumed that their use as icons to identify monitored systems falls under legal "fair use" of copyrighted material.

Naturally, there are no warranties of any kind.
