# Last update: 2006/07/11
# 
## Load the IPMI device drivers 
/sbin/modprobe ipmi_devintf

maj=`cat /proc/devices | awk '/ipmidev/{print $1}'`
echo $maj
if [ -c /dev/ipmi0 ]
then
   rm -f /dev/ipmi0
   /bin/mknod /dev/ipmi0 c $maj 0
else
   /bin/mknod /dev/ipmi0 c $maj 0
fi

IPMI_DRIVERS="ipmi_si_drv ipmi_si ipmi_kcs_drv"
for driver in $IPMI_DRIVERS; do 
  find /lib/modules/`uname -r`/kernel/drivers/char/ipmi | grep $driver > /dev/null
  RETURN_VALUE=$?
  if [ $RETURN_VALUE -eq 0 ] ; then
    modprobe $driver
    break
  fi
done


