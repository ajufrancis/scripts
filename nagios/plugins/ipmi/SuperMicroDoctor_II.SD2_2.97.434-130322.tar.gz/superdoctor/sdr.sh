#!/bin/bash

UPDATE="2010/01/07"
OUTPUT_TXT=`basename $0 .sh`-`date +%Y%m%d-%H%M`.txt

HEADLINE="
###########################################################################
# SuperDoctor Report Shell Script                                        
# This shell script is used to collect information for troubleshooting.    
# Copyright @ Super Micro Computer, Inc.                                   
# Update: $UPDATE                                                          
###########################################################################
"

function showHeadline()
{
    echo "$HEADLINE"
}

function showCurrentTime()
{
    date
}
function showSystemInfo()
{
    uname -a
}

function showBIOSDMI()
{
    dmidecode
}

function showLinuxDistribution()
{
    if [ -f  /etc/issue ]; then
        cat /etc/issue
    else
        echo "N/A, Not available."
    fi
}
function showSDInfo()
{
    sdt
    if [ -f /etc/SuperD.ini ]; then
        cat /etc/SuperD.ini
    else
        echo "N/A, Not available."
    fi
}

function showPCIInfo()
{
    lspci -n 
    lspci -vv
}

function showLoadedModule()
{
    lsmod
}

function showI2CBus()
{
    if [ -e /proc/bus/i2c ]; then
        cat /proc/bus/i2c
    else
        echo "N/A, Not available."
    fi
}

function main()
{
    showHeadline

    echo "---------------------------------------------------------------------------"
    echo ">>> Current time: "
    showCurrentTime

    echo "---------------------------------------------------------------------------"
    echo ">>> System info: "
    showSystemInfo

    echo "---------------------------------------------------------------------------"
    echo ">>> Linux distribution info: "
    showLinuxDistribution

    echo "---------------------------------------------------------------------------"
    echo ">>> BIOS/DMI info: "
    showBIOSDMI

    echo "---------------------------------------------------------------------------"
    echo ">>> PCI info: "
    showPCIInfo

    echo "---------------------------------------------------------------------------"
    echo ">>> Loaded modules Info before running SuperDoctor: "
    showLoadedModule

    echo "---------------------------------------------------------------------------"
    echo ">>> SuperDoctor info: "
    showSDInfo

    echo "---------------------------------------------------------------------------"
    echo ">>> Loaded modules Info after running SuperDoctor: "
    showLoadedModule

    echo "---------------------------------------------------------------------------"
    echo ">>> I2C bus info: "
    showI2CBus
}


showHeadline
main > $OUTPUT_TXT
if [ -f $OUTPUTT_TXT ]; then
    echo ">>> SuperDoctor Report: $OUTPUT_TXT"
    ls -l $OUTPUT_TXT
    echo
else
    echo ">>> Error: Cannot create SuperDoctor Report!"
    echo
fi

