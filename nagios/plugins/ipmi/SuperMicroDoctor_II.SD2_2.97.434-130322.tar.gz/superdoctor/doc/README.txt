*****************************************************************************
 SuperDoctor II - Linux version
 Copyright(c) 1993-2011 by Super Micro Computer, Inc. http://supermicro.com/
*****************************************************************************
Last update: 2011/12/07

Description
===========
SuperDoctor II allows users to monitor 
 - fan status             - system voltages        - system temperatures
 - chassis intrusion      - power supply failure

The latest version of SuperDoctor II for Linux is available at
ftp://ftp.supermicro.com/utility/SuperDoctor_II/Linux/

Usage
=====
superdoctor                          -> full function
superdoctor -t                       -> text mode, running only once
superdoctor -t -i 5                  -> text mode, running every 5 seconds
superdoctor -r "Chassis Intrusion"   -> reset the chassis intrusion
superdoctor -h                       -> showing this page
superdoctor -v                       -> showing version information

sdt                                   -> running only once
sdt -i 5                              -> running every 5 seconds
sdt -r "Chassis Intrusion"            -> reset the chassis intrusion
sdt -h                                -> showing this page
sdt -v                                -> showing version information

Note
====
sdt supports text mode only. Users can run it without GUI libraries.


