# Last update: 2004/11/08
# 
## Load the smbmc driver
/sbin/insmod /usr/supermicro/smbmc.o
maj=`cat /proc/devices | awk '/smbmc/{print $1}'`

if [ -c /dev/smbmc ]
then
   rm -f /dev/smbmc
   /bin/mknod /dev/smbmc c $maj 0
else
   /bin/mknod /dev/smbmc c $maj 0
fi

