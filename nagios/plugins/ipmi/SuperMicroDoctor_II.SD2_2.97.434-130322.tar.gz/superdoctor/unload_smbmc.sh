# Last update: 2004/11/08
#
## Unload the smbmc.o driver
lsmod | grep smbmc && rmmod smbmc
rm -f /dev/smbmc

