# Last update: 2004/11/08
#
## Unload the IPMI device drivers 
IPMI_DRIVERS="ipmi_si ipmi_si_drv ipmi_kcs_drv ipmi_devintf ipmi_msghandler"

for driver in $IPMI_DRIVERS; do
  lsmod | grep ^$driver > /dev/null
  RETURN_VALUE=$?
  if [ $RETURN_VALUE -eq 0 ] ; then
    rmmod $driver
  fi
done

