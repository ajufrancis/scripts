<?php
// File only used for tests and commandline tool

return array(
    "api_key"    => "", // YOUR_API_KEY
    "secret_key" => "", // YOUR_SECRET_KEY
    "endpoint"   => "", // example: http://YOUR_DOMAIN_NAME/client/api
);