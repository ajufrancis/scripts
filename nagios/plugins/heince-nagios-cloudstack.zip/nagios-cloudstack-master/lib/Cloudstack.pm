package Cloudstack;
use App::Cmd::Setup -app;

1;