<?php
#################################################################
#        _  _ ___ _____ _   ___ ___    ___ _  _ ___ ___ _  __   #
#       | \| | __|_   _/_\ | _ \ _ \  / __| || | __/ __| |/ /   #
#       | .` | _|  | |/ _ \|  _/  _/ | (__| __ | _| (__| ' <    #
#       |_|\_|___| |_/_/ \_\_| |_|    \___|_||_|___\___|_|\_\   #
#---------------------------------------------------------------#
# Author: Benjamin Odenthal                                     #
# Contact: support@tuxclouds.org                                #
# File: check_mk-netapp_cpu.php			                #               
# Version: 1.0                                                  #
# Revision: 14.Oct.2010                                         #
# Description: PNP4NAGIOS Template for the check netapp_cpu     #
#################################################################

$opt[1] = "--vertical-label 'Percent' -l0 -u100 --title \"CPU Usage of $hostname\" ";

$def[1] = "DEF:cpuusage=$RRDFILE[1]:$DS[1]:MAX ";
$def[1] .= "AREA:cpuusage#60f020:\"CPU Usage\" ";
$def[1] .= "LINE:cpuusage#40d010 ";
$def[1] .= "HRULE:$WARN[1]#FFFF00 ";
$def[1] .= "HRULE:$CRIT[1]#FF0000 ";
?>
