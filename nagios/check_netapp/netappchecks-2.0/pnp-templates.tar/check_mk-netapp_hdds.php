<?php
#################################################################
#        _  _ ___ _____ _   ___ ___    ___ _  _ ___ ___ _  __   #
#       | \| | __|_   _/_\ | _ \ _ \  / __| || | __/ __| |/ /   #
#       | .` | _|  | |/ _ \|  _/  _/ | (__| __ | _| (__| ' <    #
#       |_|\_|___| |_/_/ \_\_| |_|    \___|_||_|___\___|_|\_\   #
#---------------------------------------------------------------#
# Author: Benjamin Odenthal                                     #
# Contact: support@tuxclouds.org                                #
# File: check_mk-netapp_hdds.php		                #               
# Version: 1.1                                                  #
# Revision: 07.Mar.2011                                         #
# Description: PNP4NAGIOS Template for the check netapp_hdds    #
#################################################################

$opt[1] = "--vertical-label 'Disks' -l 0 -u 1 --title \"NetApp Disk Summary of $hostname\" ";

$def[1] = "DEF:disks=$RRDFILE[1]:$DS[1]:MAX ";
$def[1] .= "DEF:active=$RRDFILE[2]:$DS[2]:MAX ";
$def[1] .= "DEF:spare=$RRDFILE[3]:$DS[3]:MAX ";
$def[1] .= "DEF:prefail=$RRDFILE[4]:$DS[4]:MAX ";
$def[1] .= "DEF:failed=$RRDFILE[5]:$DS[5]:MAX ";
#$def[1] .= "AREA:disks#BDBDBD:\"Disks\" ";
$def[1] .= "LINE:disks#0000FF:\"Disks\" ";
$def[1] .= "GPRINT:disks:LAST:\"%6.0lf\" " ;
#$def[1] .= "AREA:active#04B404:\"Active\" ";
$def[1] .= "LINE:active#04B404:\"Active\" ";
$def[1] .= "GPRINT:active:LAST:\"%6.0lf\" " ;
$def[1] .= "LINE:spare#FFFF00:\"Spare\" ";
#$def[1] .= "AREA:spare#FFFF00:\"Spare\" ";
$def[1] .= "GPRINT:spare:LAST:\"%6.0lf\" " ;
$def[1] .= "LINE:prefail#B45F04:\"Prefail\" ";
$def[1] .= "GPRINT:prefail:LAST:\"%6.0lf\" " ;
$def[1] .= "LINE:failed#FF0000:\"Failed\" ";
$def[1] .= "GPRINT:failed:LAST:\"%6.0lf\" " ;
?>

