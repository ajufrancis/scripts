<?php

return array(
    'API_ENDPOINT' => 'http://cloudmgr.example.com:8080/client/api',
    'API_KEY'      => 'your_api_key',
    'API_SECRET'   => 'your_secret_key'
);
