({
    appDir: "./",
    baseUrl: "lib",
    dir: "./build",
	mainConfigFile: "main.js",
    modules: [
        {
            name: "../main"
        }
    ]
})